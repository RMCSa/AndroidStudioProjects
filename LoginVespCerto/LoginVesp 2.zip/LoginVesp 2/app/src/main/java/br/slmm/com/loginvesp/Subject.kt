package br.slmm.com.loginvesp

data class Subject(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val professor: String = " "
)

